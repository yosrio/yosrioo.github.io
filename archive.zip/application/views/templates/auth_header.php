<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title><?= $title; ?></title>
  	<link href="<?= base_url('assets/'); ?>css/bootstrap.min.css" rel="stylesheet">
	<link href="<?= base_url('assets/'); ?>css/login-style.css" rel="stylesheet" type="text/css"></link>
	<script src="<?= base_url('assets/'); ?>js/bootstrap.min.js" rel="stylesheet"></script>
	<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

</head>

<body class="bg-gradient-primary">